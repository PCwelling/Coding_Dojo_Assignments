﻿using System;

namespace human
{
    class Program
    {
        static void Main(string[] args)
        {
            Human Hugo = new Human(Hugo);
        }
    }
}

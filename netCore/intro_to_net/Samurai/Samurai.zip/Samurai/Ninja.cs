public class Ninja : Human
{
    public int dexterity = 175;

    public void steal(target)
    {
        health += 10
    }
    public void get_away()
    {
        health -= 15
    }
} 